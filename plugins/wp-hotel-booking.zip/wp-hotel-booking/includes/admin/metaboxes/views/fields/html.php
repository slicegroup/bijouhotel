<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
echo sprintf( '%s', $field['content'] );
?>